export const handler = async (event) => {
    return "Hello, " + event.who + "!";
  };